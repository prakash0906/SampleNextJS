export const validate: typeof import('./validate').validate;
export const ValidationError: typeof import('./ValidationError').default;
