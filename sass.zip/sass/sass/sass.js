#!/usr/bin/env node

var module = require('./sass.dart.js');
module.cli_pkg_main_0_(process.argv.slice(2));
